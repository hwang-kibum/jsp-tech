-- ============================================================
-- misoBackup 플러그인 메뉴 등록 (엔지니어 메뉴)
--   엔지니어 권한(user.ENGINEER_AUTH_YN = 'Y') 사용자에게만 보이고, 다른 사용자에게는 숨겨집니다.
--   권한 관리(auth_menu_map)에는 등록하지 않습니다.
--   1) 아래 값을 해당 서버의 '시스템 관리' MENU_ID 로 수정합니다. (README 3-3 조회 쿼리 참고)
--   2) 포털 DB 에 접속해 실행합니다. 이미 등록돼 있으면 엔지니어 메뉴로 바꿉니다.
-- ============================================================
SET @P_MENU_ID = 9;   -- 상위 메뉴 '시스템 관리' 의 MENU_ID

INSERT INTO menu (MENU_GROUP_ID, MENU_NM, MENU_NM_ENG, ORD_NO, USE_YN, ENGINEER_YN, MENU_LINK_URL, MENU_DESC, P_MENU_ID, INSERT_USER, UPDATE_USER, LINKAGE_YN)
SELECT NULL, '시스템 백업', 'System Backup', 27, 'Y', 'Y', '/web/plugins/misoBackup/index.jsp', 'DB·웹앱·업로드 파일 백업', @P_MENU_ID, 'SYSTEM', 'SYSTEM', 'N'
  FROM DUAL
 WHERE NOT EXISTS (SELECT 1 FROM menu WHERE MENU_LINK_URL = '/web/plugins/misoBackup/index.jsp');

-- 이전 버전으로 등록된 메뉴 : 엔지니어 메뉴로 바꾸고 권한 관리 연결 제거
SET @id = (SELECT MENU_ID FROM menu WHERE MENU_LINK_URL = '/web/plugins/misoBackup/index.jsp' ORDER BY MENU_ID LIMIT 1);
UPDATE menu SET ENGINEER_YN = 'Y' WHERE MENU_ID = @id;
DELETE FROM auth_menu_map WHERE MENU_ID = @id;

-- 결과 확인 (ENGINEER_YN = Y, 권한연결 0)
SELECT m.MENU_ID, m.MENU_NM, m.P_MENU_ID, m.USE_YN, m.ENGINEER_YN,
       (SELECT COUNT(*) FROM auth_menu_map a WHERE a.MENU_ID = m.MENU_ID) AS 권한연결
  FROM menu m
 WHERE m.MENU_LINK_URL = '/web/plugins/misoBackup/index.jsp';
-- 엔지니어 권한 사용자
SELECT USER_ID, USER_NM, AUTH_ID FROM user WHERE ENGINEER_AUTH_YN = 'Y';
