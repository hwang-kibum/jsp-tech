<%--
  misoBackup 플러그인 : 시스템 관리 > 시스템 백업 메뉴 (엔지니어 메뉴. 사용자 엔지니어 권한(ENGINEER_AUTH_YN=Y)이 있어야 조회·다운로드·백업·삭제·복구 가능)
  위치 : ROOT/web/plugins/misoBackup/index.jsp + lib/misoBackup-core.jar  (war 소스에서는 src/main/webapp/web/plugins/misoBackup/)
  엔진 : lib/misoBackup-core.jar 를 별도 클래스로더로 읽어 사용 (Java 8 이상, 의존성 없음). jar 를 바꾸면 다음 요청 때 다시 읽음
  설정 : system.properties 의 backup.dir / backup.webapp.dir / backup.fileupload.dir / backup.editor.dir / backup.cron / backup.targets / backup.keep / backup.restore.keep
  자동 : Tomcat conf/web.xml 에 이 JSP 를 load-on-startup 으로 등록하면 기동 시 스케줄러가 시작됨 (README 참고)
  호환 : Tomcat 9(javax, Java 8) / Tomcat 11(jakarta) 포털 모두 사용 (ServletContext 타입을 코드에 쓰지 않음)
--%><%@ page import="java.io.*,java.net.*,java.nio.file.*,java.util.*,java.util.function.*"%><%!
	static final String MENU_URL = "/web/plugins/misoBackup/index.jsp";
	static final String JAR = "web/plugins/misoBackup/lib/misoBackup-core.jar";
	static final String HOLDER_KEY = "misoBackup.engine";
	static final String[][] TARGETS = {
		{"db", "DB 덤프", "db.sql.gz"},
		{"root", "웹앱 ROOT", "webapps_ROOT.tar.gz"},
		{"upload", "업로드 파일", "upload_files.tar.gz"},
	};

	// Tomcat 기동 시(conf/web.xml load-on-startup) 또는 첫 요청 시 엔진과 자동 백업 스케줄러 시작
	public void jspInit() {
		try {
			engine();
		} catch (Throwable e) {
			getServletContext().log("misoBackup 엔진 시작 실패", e);
		}
	}

	javax.sql.DataSource dataSource() {
		try {
			return org.springframework.web.context.support.WebApplicationContextUtils
					.getRequiredWebApplicationContext(getServletContext()).getBean("dataSource", javax.sql.DataSource.class);
		} catch (Exception e) {
			getServletContext().log("misoBackup dataSource 조회 실패", e);
			return null;
		}
	}

	// 엔진은 웹앱마다 하나 (application 속성에 보관). jar 가 바뀌면 이전 엔진을 멈추고 다시 로드
	@SuppressWarnings("unchecked")
	Function<Map<String, Object>, Object> engine() throws Exception {
		Map<String, Object> holder;
		synchronized (getServletContext()) {
			holder = (Map<String, Object>) getServletContext().getAttribute(HOLDER_KEY);
			if (holder == null) {
				holder = new HashMap<>();
				getServletContext().setAttribute(HOLDER_KEY, holder);
			}
		}
		synchronized (holder) {
			String root = getServletContext().getRealPath("/");
			File jar = new File(root, JAR);
			if (!jar.isFile()) throw new FileNotFoundException("엔진 jar 가 없습니다: " + jar);
			String ver = jar.lastModified() + ":" + jar.length();
			Function<Map<String, Object>, Object> e = (Function<Map<String, Object>, Object>) holder.get("engine");
			if (e != null && ver.equals(holder.get("ver"))) return e;
			if (e != null) e.apply(Collections.singletonMap("cmd", "shutdown"));

			// 사용 중인 jar 를 덮어써도 영향이 없도록 임시 복사본을 읽음
			File copy = File.createTempFile("misoBackup-core-", ".jar");
			copy.deleteOnExit();
			Files.copy(jar.toPath(), copy.toPath(), StandardCopyOption.REPLACE_EXISTING);
			ClassLoader cl = new URLClassLoader(new URL[]{copy.toURI().toURL()}, Thread.currentThread().getContextClassLoader());

			final Map<String, Object> h = holder;
			Map<String, Object> init = new HashMap<>();
			init.put("root", root);
			init.put("dataSource", dataSource());
			// 웹앱이 내려가면(application 속성 정리) 스케줄러도 종료
			init.put("alive", (BooleanSupplier) () -> {
				try { return getServletContext().getAttribute(HOLDER_KEY) == h; } catch (Throwable x) { return false; }
			});
			init.put("log", (Consumer<String>) msg -> getServletContext().log(msg));
			e = (Function<Map<String, Object>, Object>) cl.loadClass("misobackup.Engine").getConstructor(Map.class).newInstance(init);
			holder.put("engine", e);
			holder.put("ver", ver);
			return e;
		}
	}

	static Map<String, Object> cmd(Object... kv) {
		Map<String, Object> m = new HashMap<>();
		for (int i = 0; i < kv.length; i += 2) m.put((String) kv[i], kv[i + 1]);
		return m;
	}

	// breadcrumb 용 {상위 메뉴명, 메뉴명}. 조회 실패(DB 복구 중 등) 시 기본값 유지
	static void menuNames(javax.sql.DataSource ds, String[] names) {
		if (ds == null) return;
		try (java.sql.Connection c = ds.getConnection();
			 java.sql.PreparedStatement ps = c.prepareStatement("SELECT pm.MENU_NM, m.MENU_NM FROM menu m"
					+ " LEFT JOIN menu pm ON pm.MENU_ID = m.P_MENU_ID WHERE m.MENU_LINK_URL = ? ORDER BY m.MENU_ID LIMIT 1")) {
			ps.setString(1, MENU_URL);
			try (java.sql.ResultSet rs = ps.executeQuery()) {
				if (rs.next()) { names[0] = rs.getString(1); names[1] = rs.getString(2); }
			}
		} catch (Exception ignore) {}
	}

	static String esc(Object o) {
		String s = o == null ? "" : String.valueOf(o);
		return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;");
	}

	static String json(Object o) {
		if (o == null) return "null";
		if (o instanceof Boolean || o instanceof Number) return o.toString();
		if (o instanceof Map) {
			StringBuilder sb = new StringBuilder("{");
			for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) {
				if (sb.length() > 1) sb.append(',');
				sb.append(json(String.valueOf(e.getKey()))).append(':').append(json(e.getValue()));
			}
			return sb.append('}').toString();
		}
		if (o instanceof Collection) {
			StringBuilder sb = new StringBuilder("[");
			for (Object v : (Collection<?>) o) { if (sb.length() > 1) sb.append(','); sb.append(json(v)); }
			return sb.append(']').toString();
		}
		StringBuilder sb = new StringBuilder("\"");
		for (char c : o.toString().toCharArray()) {
			if (c == '"' || c == '\\') sb.append('\\').append(c);
			else if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
			else if (c == '<') sb.append("\\u003c");
			else sb.append(c);
		}
		return sb.append('"').toString();
	}
%><%
	// 로그인 사용자(userInfo)의 엔지니어 권한(user.ENGINEER_AUTH_YN)이 Y 일 때만 모든 기능 허용. 메뉴 권한(auth_menu_map)은 쓰지 않음
	Object user = session.getAttribute("userInfo");
	com.jiransnc.miso.domains.common.UserModel um = user instanceof com.jiransnc.miso.domains.common.UserModel
			? (com.jiransnc.miso.domains.common.UserModel) user : null;
	String userId = um == null ? null : um.getUserId();
	boolean engineer = um != null && "Y".equals(um.getEngineerAuthYn());
	String act = request.getParameter("act");

	if (act != null) {
		if (!engineer) {
			if (!act.equals("status")) application.log("misoBackup 권한 없음 act=" + act + " user=" + userId + " ip=" + request.getRemoteAddr());
			response.sendError(403);
			return;
		}
		Function<Map<String, Object>, Object> eng = engine();
		String name = request.getParameter("name");

		if (act.equals("download")) {
			String fname = request.getParameter("file");
			Object f = eng.apply(cmd("cmd", "file", "name", name, "file", fname));
			if (!(f instanceof File)) { response.sendError(404); return; }
			File file = (File) f;
			application.log("misoBackup download user=" + userId + " ip=" + request.getRemoteAddr() + " file=" + name + "/" + fname);
			out.clear();
			out = pageContext.pushBody();
			response.setContentType("application/gzip");
			response.setHeader("Content-Disposition", "attachment; filename=\"portal_" + name + "_" + fname + "\"");
			response.setContentLengthLong(file.length());
			try (OutputStream os = response.getOutputStream()) { Files.copy(file.toPath(), os); }
			return;
		}

		response.setContentType("application/json;charset=UTF-8");
		Object res;
		if (act.equals("status")) {
			res = eng.apply(cmd("cmd", "status"));
		} else if (!"POST".equals(request.getMethod())) {
			response.setStatus(405);
			res = cmd("error", "POST only");
		} else if (act.equals("backup")) {
			String[] ts = request.getParameterValues("t");
			res = eng.apply(cmd("cmd", "backup", "targets", ts == null ? new ArrayList<String>() : Arrays.asList(ts), "trigger", "수동"));
		} else if (act.equals("delete")) {
			res = eng.apply(cmd("cmd", "delete", "name", name));
		} else if (act.equals("restore")) {
			String[] ts = request.getParameterValues("t");
			res = eng.apply(cmd("cmd", "restore", "name", name, "targets", ts == null ? new ArrayList<String>() : Arrays.asList(ts),
					"pre", "Y".equals(request.getParameter("pre"))));
		} else {
			response.setStatus(400);
			res = cmd("error", "unknown act");
		}
		if (res instanceof Map && ((Map<?, ?>) res).get("error") != null && response.getStatus() == 200) response.setStatus(400);
		if (!act.equals("status")) application.log("misoBackup " + act + " 요청 user=" + userId + " ip=" + request.getRemoteAddr() + " 결과=" + json(res));
		out.print(json(res));
		return;
	}

	// 포털 메뉴 클릭 시 $('#bodyContents').load(url) 로 본문에 삽입되므로 HTML 조각으로 출력 (다른 관리 메뉴와 같은 breadcrumb / search / misoGrid 구성)
	if (!engineer) {
		response.setStatus(403);
%><div style="padding:40px">이 메뉴는 엔지니어 권한이 있는 사용자만 사용할 수 있습니다.</div><%
		return;
	}
	String[] menuNames = {null, "시스템 백업"};
	menuNames(dataSource(), menuNames);
	String engineError = null;
	Map<?, ?> cfg = new HashMap<>();
	try {
		cfg = (Map<?, ?>) ((Map<?, ?>) engine().apply(cmd("cmd", "status"))).get("config");
	} catch (Throwable e) {
		engineError = e.toString();
	}
	Object dir = cfg.get("dir");
	List<Object> targetInfo = new ArrayList<>();
	for (String[] t : TARGETS) targetInfo.add(cmd("key", t[0], "name", t[2], "label", t[1]));
	String autoLabel = "";
	for (String[] t : TARGETS) if (String.valueOf(cfg.get("autoTargets")).contains(t[0])) autoLabel += (autoLabel.isEmpty() ? "" : ", ") + t[1];
%><style nonce="${cspNonce}">
#misoBackup .search label{margin:0 18px 0 0;font-weight:normal;cursor:pointer}
#misoBackup .search input[type=checkbox]{vertical-align:-2px;margin-right:4px}
#misoBackup .mb-muted{color:#888}
#misoBackup .mb-err{color:#d9534f}
#misoBackup .st-완료{color:#3c763d}#misoBackup .st-실패{color:#d9534f;cursor:help}#misoBackup .st-진행{color:#337ab7;font-weight:bold}
#misoBackup .k-grid a.mb-down{color:#337ab7;text-decoration:underline}
#misoBackup .mb-prog{display:none;margin-top:6px;width:520px;max-width:100%}
#misoBackup .mb-bar{position:relative;height:18px;background:#eee;border:1px solid #ccc;border-radius:3px;overflow:hidden}
#misoBackup .mb-fill{height:100%;width:0;background:#337ab7;transition:width .5s}
#misoBackup .mb-pct{position:absolute;left:0;right:0;top:0;line-height:18px;text-align:center;font-size:12px;color:#222}
#misoBackup .mb-time{font-size:12px;margin-top:2px}
.mb-restore{padding:14px 18px}
.mb-restore p{margin:0 0 10px}
.mb-restore label{display:block;margin:4px 0 4px 6px;font-weight:normal;cursor:pointer}
.mb-restore input[type=checkbox]{vertical-align:-2px;margin-right:5px}
.mb-restore .mb-note{margin:0 0 6px 26px;font-size:12px;word-break:break-all}
.mb-restore ul{margin:10px 0 0;padding-left:18px;color:#a94442;font-size:12px}
.mb-restore ul li{margin-bottom:3px}
.mb-restore .mb-btns{text-align:right;margin-top:14px}
</style>
<div id="misoBackup" style="height: 100%;">
	<!-- PAGE TITLE -->
	<ul class="breadcrumb">
<% if (menuNames[0] != null) { %>		<li class="active"><%= esc(menuNames[0]) %></li>
<% } %>		<li class="active"><%= esc(menuNames[1]) %></li>
	</ul>
	<!-- END TITLE  -->
	<div class="page-content-wrap" style="height:calc( 100% - 30px );">
		<div class="search">
			<table>
				<colgroup>
					<col width="100px">
					<col width="380px">
					<col width="100px">
					<col>
				</colgroup>
				<tr>
					<th>백업 대상</th>
					<td>
<% for (String[] t : TARGETS) { %>						<label><input type="checkbox" name="mbTarget" value="<%= t[0] %>" checked><%= t[1] %></label>
<% } %>					</td>
					<th>저장 위치</th>
					<td>
<% if (engineError != null) { %>						<span class="mb-err">엔진을 불러오지 못했습니다 : <%= esc(engineError) %></span>
<% } else if (dir == null) { %>						<span class="mb-err">system.properties 에 backup.dir 을 설정하세요. (예: backup.dir=/data/miso/backup)</span>
<% } else { %>						<%= esc(dir) %> <span class="mb-muted">(남은 디스크 <%= String.format("%.1f", ((Number) cfg.get("free")).longValue() / Math.pow(1024, 3)) %> GB · 완료된 백업 최신 <%= cfg.get("keep") %>개 보관)</span>
<% } %>					</td>
				</tr>
				<tr>
					<th>백업 경로</th>
					<td colspan="3">
<% if (engineError == null) { for (Object e : (List<?>) cfg.get("pathErrors")) { %>						<div class="mb-err"><%= esc(e) %></div>
<% } %>						<span class="mb-muted"><%= esc(String.join(" · ", (List<String>) cfg.get("paths"))) %></span>
<% } %>					</td>
				</tr>
				<tr>
					<th>자동 백업</th>
					<td colspan="3">
<% if (engineError != null || "".equals(cfg.get("cron"))) { %>						<span class="mb-muted">사용 안 함 (system.properties 에 backup.cron 을 설정하면 자동 백업합니다. 예: backup.cron=0 2 * * * → 매일 02:00)</span>
<% } else if (!"".equals(cfg.get("cronError"))) { %>						<span class="mb-err">backup.cron 오류 : <%= esc(cfg.get("cronError")) %></span>
<% } else { %>						<%= esc(cfg.get("cron")) %> <span class="mb-muted">(다음 실행 <%= esc(cfg.get("nextRun")) %> · 대상 <%= esc(autoLabel) %>)</span>
<% } %>					</td>
				</tr>
				<tr>
					<th>최근 복구</th>
					<td colspan="3"><span class="mb-last"><%= esc(cfg.get("lastRestore") == null || "".equals(cfg.get("lastRestore")) ? "-" : cfg.get("lastRestore")) %></span></td>
				</tr>
				<tr>
					<th>진행 상태</th>
					<td colspan="3">
						<span class="mb-msg">-</span>
						<div class="mb-prog">
							<div class="mb-bar"><div class="mb-fill"></div><div class="mb-pct"></div></div>
							<div class="mb-time mb-muted"></div>
						</div>
						<div style="float:right; margin-top:5px;">
							<miso:button btnClass="search" id="mbRefreshBtn" code="search" />
							<miso:button btnClass="register" id="mbBackupBtn" text="백업 실행" />
						</div>
					</td>
				</tr>
			</table>
		</div>
		<div id="mbBackupGrid"></div>
	</div>
</div>
<script nonce="${cspNonce}">
$(function(){
	var API = '<%= request.getContextPath() + MENU_URL %>';
	var CSRF = {header: '${_csrf.headerName}', token: '${_csrf.token}'};
	var READY = <%= engineError == null && dir != null %>;
	var TARGETS = <%= json(targetInfo) %>;
	var $root = $('#misoBackup'), $msg = $root.find('.mb-msg'), $go = $('#mbBackupBtn');
	var GRID, timer, waiting = '', restarting = 0, restoreAt = 0;	// waiting : 'backup' | 'restore', restarting : WAS 재기동 대기 시작 시각

	var $prog = $root.find('.mb-prog');
	var hms = function(sec){ var m = Math.floor(sec / 60), s = sec % 60; return m >= 60 ? Math.floor(m / 60) + '시간 ' + (m % 60) + '분' : m > 0 ? m + '분 ' + s + '초' : s + '초'; };
	function progress(st){
		if (!st.running) { $prog.hide(); return; }
		var p = st.percent >= 0 ? st.percent : 0;
		$prog.show();
		$prog.find('.mb-fill').css('width', p + '%');
		$prog.find('.mb-pct').text(st.percent >= 0 ? p + '%' : '계산 중');
		$prog.find('.mb-time').text(st.elapsed >= 0 ? '경과 ' + hms(st.elapsed) + (st.eta >= 0 ? ' · 남은 시간 약 ' + hms(st.eta) : '') : '');
	}
	var fmt = function(b){ return b >= Math.pow(1024,3) ? (b/Math.pow(1024,3)).toFixed(2)+' GB' : (b/Math.pow(1024,2)).toFixed(1)+' MB'; };
	var esc = function(s){ return kendo.htmlEncode(s == null ? '' : String(s)); };

	// 포털 공통 다이얼로그 (없으면 브라우저 기본 창)
	function alertDialog(msg, icon){
		if (kendo.ui.ExtAlertDialog) kendo.ui.ExtAlertDialog.show({title: '<miso:msg code="alert"/>', message: esc(msg), icon: icon || 'k-ext-information'});
		else alert(msg);
	}
	function confirmDialog(msg, ok){
		try {
			if (kendo.ui.ExtOkCancelDialog) {
				var big = msg.length > 60;	// 긴 문구는 창을 키우고 줄바꿈 표시
				$.when(kendo.ui.ExtOkCancelDialog.show({title: '<miso:msg code="alert"/>', message: esc(msg).replace(/\n/g, '<br>'), icon: 'k-ext-warning',
						width: big ? '460px' : undefined, height: big ? '220px' : undefined}))
					.done(function(r){ if (r.button === 'OK') ok(); });
				return;
			}
		} catch (e) { showError(e); }
		if (confirm(msg)) ok();
	}
	function showError(e){
		$msg.html('<span class="mb-err">화면 오류 : ' + esc(e && e.message || e) + '</span>');
		if (window.console) console.error('misoBackup', e);
	}

	function post(data){
		var h = {};
		if (CSRF.header) h[CSRF.header] = CSRF.token;
		return $.ajax({url: API, type: 'POST', headers: h, data: data, traditional: true, dataType: 'json'})
			.then(null, function(xhr){ return $.Deferred().resolve(xhr.responseJSON || {error: '서버 오류 (' + xhr.status + ')'}); });
	}

	function initGrid(){
		var cols = [
			{ field: 'when', title: '백업 시각', width: '160px', attributes: { style: 'text-align: center;' } },
			{ field: 'trigger', title: '구분', width: '70px', attributes: { style: 'text-align: center;' } },
			{ field: 'status', title: '상태', width: '80px', attributes: { style: 'text-align: center;' },
				template: function(d){ return '<span class="st-' + d.status.slice(0,2) + '" title="' + esc(d.error) + '">' + esc(d.status) + '</span>'; } }
		];
		$.each(TARGETS, function(i, t){
			cols.push({ title: t.label, width: '160px', attributes: { style: 'text-align: center;' }, sortable: false,
				template: function(d){
					var f = d.fileMap[t.name];
					return f ? '<a class="mb-down" href="' + API + '?act=download&name=' + d.name + '&file=' + f.name + '">다운로드</a> <span class="mb-muted">' + fmt(f.size) + '</span>' : '-';
				} });
		});
		cols.push({ field: 'total', title: '합계', width: '100px', attributes: { style: 'text-align: right;' }, template: function(d){ return fmt(d.total); } });
		cols.push({ title: '복구', width: '90px', attributes: { style: 'text-align: center;' }, sortable: false,
			template: function(d){ return d.status !== '완료' ? '' : "<button type='button' class='k-button mb-restore-btn' data-name='" + d.name + "' style='border-style: solid; background-color:#f9f9f9; border-color:#a9a9a9;'><span class='k-icon k-i-undo'></span>복구</button>"; } });
		cols.push({ title: '삭제', width: '90px', attributes: { style: 'text-align: center;' }, sortable: false,
			template: function(d){ return d.status === '진행 중' ? '' : "<button type='button' class='k-button mb-del' data-name='" + d.name + "' style='border-style: solid; background-color:#f9f9f9; border-color:#a9a9a9;'><span class='k-icon k-i-minus'></span>삭제</button>"; } });

		// misoGrid 는 jQuery 객체가 아니라 kendoGrid 위젯을 반환
		GRID = $('#mbBackupGrid').misoGrid({
			dataSource: new kendo.data.DataSource({ data: [], pageSize: <miso:prop code="kendogrid.pageSize"/> }),
			filterable: false,
			sortable: true,
			columns: cols
		}) || $('#mbBackupGrid').data('kendoGrid');
	}

	function refresh(){
		clearTimeout(timer);
		if (!document.body.contains($root[0])) return;   // 다른 메뉴로 이동하면 중지
		$.ajax({url: API, data: {act: 'status'}, dataType: 'json', cache: false}).done(function(d){
			if (d.error) { $msg.html('<span class="mb-err">' + esc(d.error) + '</span>'); return; }
			$go.prop('disabled', d.state.running || !READY).toggleClass('k-state-disabled', d.state.running || !READY);
			progress(d.state);
			$root.find('.mb-last').text(d.config.lastRestore || '-');
			var restoring = /복구/.test(d.state.trigger);
			if (d.state.running) $msg.text((restoring ? '복구 진행 중 (' : '백업 진행 중 (') + d.state.trigger + ') : ' + d.state.name + ' - ' + d.state.step);
			else if (d.state.error) { $msg.html('<span class="mb-err">실패 : ' + esc(d.state.error) + '</span>'); waiting = ''; restarting = restoreAt = 0; }
			else if (restarting) { $msg.text('WAS 가 재기동되었습니다. 복구 결과 : ' + (d.config.lastRestore || '-')); restarting = restoreAt = 0; waiting = ''; }
			else if (waiting) { $msg.text(waiting === 'restore' ? '복구가 완료되었습니다. ' + (d.config.lastRestore || '') : '백업이 완료되었습니다.'); waiting = ''; restoreAt = 0; }
			// 웹앱 ROOT 복구는 이 단계에서 WAS 가 내려감 → 이후 상태 조회 실패는 재기동 대기로 처리
			if (d.state.running && /WAS 재기동/.test(d.state.step) && !restarting) restarting = new Date().getTime();
			$.each(d.backups, function(i, b){ b.fileMap = {}; $.each(b.files, function(j, f){ b.fileMap[f.name] = f; }); });
			if (GRID) GRID.dataSource.data(d.backups);
			timer = setTimeout(refresh, d.state.running ? 1000 : 10000);
		}).fail(function(xhr){
			// 복구 중(DB 복구 중 권한 조회 실패, WAS 재기동)에는 실패해도 계속 확인
			var since = restarting || restoreAt, now = new Date().getTime();
			if (since && now - since < 15 * 60000) {
				var t = hms(Math.round((now - since) / 1000));
				if (restarting) { $prog.hide(); $msg.text('WAS 재기동 중입니다. 다시 연결될 때까지 기다립니다... (' + t + ')'); }
				else $msg.text('복구 진행 중입니다... (' + t + ')');	// 진행률 막대는 마지막 값 유지
				timer = setTimeout(refresh, 3000);
				return;
			}
			$msg.html('<span class="mb-err">상태 조회 실패 (' + xhr.status + ')' + (xhr.status == 403 ? ' : 권한이 없거나 로그인이 만료되었습니다.' : '') + '</span>');
		});
	}

	try { initGrid(); } catch (e) { showError(e); }

	$('#mbRefreshBtn').click(refresh);

	$go.click(function(){
		try {
			if (!READY) { $msg.html('<span class="mb-err">저장 위치(backup.dir) 설정 또는 엔진 오류로 백업할 수 없습니다.</span>'); return; }
			var ts = $root.find('input[name=mbTarget]:checked').map(function(){ return this.value; }).get();
			if (!ts.length) { alertDialog('백업 대상을 선택하세요.', 'k-ext-warning'); return; }
			$msg.text('백업 실행 확인 중');
			confirmDialog('선택한 대상을 지금 백업할까요?', function(){
				$msg.text('백업 요청 중');
				post({act: 'backup', t: ts}).done(function(d){
					if (d.error) { $msg.html('<span class="mb-err">' + esc(d.error) + '</span>'); alertDialog(d.error, 'k-ext-error'); return; }
					waiting = 'backup'; $go.prop('disabled', true).addClass('k-state-disabled'); $msg.text('백업을 시작했습니다.');
					refresh();
				});
			});
		} catch (e) { showError(e); }
	});

	// 복구 : 대상·복구 전 백업 선택 창 → 확인 창(ROOT 포함 시 WAS 재기동 경고) → 실행
	$('#mbBackupGrid').on('click', '.mb-restore-btn', function(){
		var name = $(this).data('name') + '', b = null;
		$.each(GRID.dataSource.data(), function(i, x){ if (x.name === name) b = x; });
		if (!b) return;
		var html = '<div class="mb-restore"><p><b>' + esc(b.when) + '</b> 백업(' + esc(name) + ')으로 복구합니다.</p><div>복구 대상</div>';
		$.each(TARGETS, function(i, t){
			if (!b.fileMap[t.name]) return;
			// 다른 위치(서버)에서 만든 ROOT 백업, 현재 서버에 경로 설정이 없는 업로드는 선택 불가
			var off = (t.key === 'root' && b.rootError) || (t.key === 'upload' && b.uploadError);
			html += '<label><input type="checkbox" class="mb-rt" value="' + t.key + '"' + (t.key === 'root' || off ? '' : ' checked') + (off ? ' disabled' : '') + '>' + esc(t.label) + ' <span class="mb-muted">(' + fmt(b.fileMap[t.name].size) + ')</span></label>';
			if (t.key === 'root' && b.rootError) html += '<div class="mb-note mb-err">' + esc(b.rootError) + '</div>';
			if (t.key === 'root' && b.rootTo) html += '<div class="mb-note mb-muted">복구 위치 : ' + esc(b.rootTo) + '<br>현재 파일 유지 : ' + $.map(b.rootKeep || [], esc).join(', ') + '</div>';
			if (t.key === 'upload' && b.uploadError) html += '<div class="mb-note mb-err">' + esc(b.uploadError) + '</div>';
			if (t.key === 'upload' && b.uploadTo) html += '<div class="mb-note mb-muted">복구 위치 : ' + $.map(b.uploadTo, esc).join('<br>') + '</div>';
		});
		html += '<label style="margin-top:10px"><input type="checkbox" class="mb-pre" checked>복구 전에 현재 상태를 먼저 백업 (권장)</label>'
			+ '<ul><li>DB 덤프 : 백업에 있는 테이블·뷰·함수를 백업 시점 내용으로 바꿉니다. 이후 변경된 데이터는 사라집니다. 백업 이후 새로 생긴 테이블은 남습니다.</li>'
			+ '<li>업로드 파일 : 백업에 있는 파일을 현재 포털의 업로드 경로(위 복구 위치)에 덮어씁니다. 이후 새로 올라온 파일은 남습니다.</li>'
			+ '<li>웹앱 ROOT : WAS 를 재기동하며 ROOT 를 통째로 바꿉니다. 재기동 동안 포털에 접속할 수 없습니다. 기존 ROOT 는 Tomcat 폴더에 ROOT_before_restore_* 로 보관합니다.</li></ul>'
			+ '<div class="mb-btns"><button type="button" class="k-primary k-button mb-ok">복구</button> <button type="button" class="k-button mb-cancel">취소</button></div></div>';
		var $w = $(html).appendTo(document.body);
		var win = $w.kendoWindow({ title: '백업 복구', modal: true, width: '520px', resizable: false,
			close: function(){ setTimeout(function(){ win.destroy(); }, 0); } }).data('kendoWindow');
		win.center().open();
		$w.find('.mb-cancel').click(function(){ win.close(); });
		$w.find('.mb-ok').click(function(){
			var ts = $w.find('.mb-rt:checked').map(function(){ return this.value; }).get(), pre = $w.find('.mb-pre').prop('checked');
			if (!ts.length) { alertDialog('복구 대상을 선택하세요.', 'k-ext-warning'); return; }
			var labels = $.map(TARGETS, function(t){ return $.inArray(t.key, ts) >= 0 ? t.label : null; }).join(', ');
			var root = $.inArray('root', ts) >= 0;
			win.close();
			confirmDialog((root ? '[주의] 웹앱 ROOT 를 복구하면 WAS(Tomcat)가 재기동되어 몇 분간 포털에 접속할 수 없습니다. 접속 중인 사용자 작업도 끊깁니다.\n\n' : '')
				+ name + ' 백업으로 ' + labels + ' 을(를) 복구할까요?' + (pre ? ' (복구 전 백업 후 진행)' : ' (복구 전 백업 없이 진행)'), function(){
				$msg.text('복구 요청 중');
				post({act: 'restore', name: name, t: ts, pre: pre ? 'Y' : 'N'}).done(function(d){
					if (d.error) { $msg.html('<span class="mb-err">' + esc(d.error) + '</span>'); alertDialog(d.error, 'k-ext-error'); return; }
					waiting = 'restore'; restoreAt = new Date().getTime(); $msg.text('복구를 시작했습니다.');
					refresh();
				});
			});
		});
	});

	$('#mbBackupGrid').on('click', '.mb-del', function(){
		var name = $(this).data('name') + '';
		confirmDialog(name + ' 백업을 삭제할까요?', function(){
			post({act: 'delete', name: name}).done(function(d){ if (d.error) alertDialog(d.error, 'k-ext-error'); refresh(); });
		});
	});

	refresh();
});
</script>
