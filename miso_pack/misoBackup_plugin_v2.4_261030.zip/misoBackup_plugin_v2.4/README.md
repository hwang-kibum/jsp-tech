# misoBackup 플러그인 설치 안내 (v2.4)

포털 관리자 화면의 `시스템 관리 > 시스템 백업` 메뉴에서 DB, 웹앱, 업로드 파일을 백업하고 복구하는 플러그인입니다.

## 1. 구성

| 파일 | 설명 |
|---|---|
| `misoBackup/index.jsp` | 백업 화면 |
| `misoBackup/lib/misoBackup-core.jar` | 백업 엔진 (DB 덤프, 압축, 자동 백업) |
| `menu_insert.sql` | 메뉴·권한 등록 SQL |
| `menu_delete.sql` | 메뉴·권한 삭제 SQL (제거 시) |

## 2. 요구 사항

- 포털 WAS : Tomcat 9 (Java 8 이상) 또는 Tomcat 11 (Java 17 이상)
- DB : MariaDB / MySQL (포털이 사용하는 DB)
- 별도 프로그램(mysqldump, tar 등) 설치 불필요. WAS 의 Java 만으로 동작합니다.
- 웹앱 ROOT 복구 기능은 Linux(bash) 에서만 사용할 수 있습니다.
- 백업 파일을 저장할 디스크 여유 공간 (DB + 웹앱 + 업로드 파일 크기 × 보관 개수)

아래 설명에서 `<ROOT>` 는 Tomcat 의 `webapps/ROOT` 경로, `<props>` 는 `<ROOT>/WEB-INF/classes/properties/system.properties` 파일입니다.

## 3. 설치

### 3-1. 플러그인 파일 복사

압축을 풀면 나오는 `misoBackup/` 폴더를 그대로 `<ROOT>/web/plugins/` 아래에 복사합니다.

```
cp -r misoBackup <ROOT>/web/plugins/
```

복사 후 `<ROOT>/web/plugins/misoBackup/index.jsp` 와 `<ROOT>/web/plugins/misoBackup/lib/misoBackup-core.jar` 가 있어야 합니다.

WAS 재기동은 필요 없습니다.

### 3-2. 백업 설정

`<props>` 를 백업한 뒤(`cp system.properties system.properties.bak_YYMMDD`) 맨 아래에 다음을 추가합니다.

```
# misoBackup plugin
backup.dir=/data/miso/backup
backup.webapp.dir=/data/miso/webapps
backup.editor.dir=/data/miso/editorImage
backup.fileupload.dir=/data/miso/fileUpload
backup.targets=db,root,upload
backup.keep=10
backup.cron=0 1 * * *
```

| 항목 | 설명 | 기본값 |
|---|---|---|
| `backup.dir` | 백업 파일 저장 경로 (필수). 없으면 생성되며, WAS 실행 계정에 쓰기 권한이 있어야 합니다. | 없음 (백업 불가) |
| `backup.webapp.dir` | 웹앱 ROOT 경로 (웹앱 백업·복구에 필수). 실제 서비스 중인 웹앱 위치(`server.xml` 의 `<Context path="/" docBase>`, 없으면 `<Tomcat>/webapps/ROOT`)와 같아야 하며, 다르면 오류로 막습니다. | 없음 (웹앱 백업·복구 불가) |
| `backup.fileupload.dir` | 업로드 경로 (업로드 백업·복구에 필수). 포털 `fileUpload.dir` 과 같은 경로 | 없음 (업로드 백업·복구 불가) |
| `backup.editor.dir` | 에디터 이미지 경로 (업로드 백업·복구에 필수). `server.xml` 의 `<Context path="/editorImage" docBase>` 와 namo `Config.xml` 의 `ImageSavePath` 와 같은 경로 | 없음 (업로드 백업·복구 불가) |
| `backup.restore.keep` | 웹앱 복구 때 백업 내용으로 바꾸지 않고 현재 파일을 유지할 웹앱 안의 파일 (상대 경로, 쉼표 구분) | `WEB-INF/classes/properties/system.properties,web/plugins/namo/config/xmls/Config.xml` |
| `backup.cron` | 자동 백업 일정. cron 형식 `분 시 일 월 요일` (예: `0 1 * * *` = 매일 01:00) | 없음 (자동 백업 안 함) |
| `backup.targets` | 자동 백업 대상. `db`, `root`, `upload` 중 쉼표로 구분 | 전체 |
| `backup.keep` | 보관할 백업 개수 (수동·자동 합산). 넘으면 오래된 것부터 삭제 | 10 |
| `backup.tomcat.stop` / `backup.tomcat.start` | 웹앱 ROOT 복구 시 WAS 종료/기동 명령. systemd 등을 쓰는 경우에만 지정 | `<Tomcat>/bin/shutdown.sh`, `startup.sh` |

설정은 저장 즉시 반영됩니다 (재기동 불필요).

- `backup.dir` 은 운영 디스크와 다른 디스크(또는 NAS)를 권장합니다.
- `backup.dir` 을 웹 경로(`<ROOT>` 아래)로 지정하지 마십시오.
- 백업 폴더는 700, 백업 파일은 600 (WAS 실행 계정만 접근) 으로 만들어집니다. `backup.dir` 을 새로 만들 때도 700 으로 만듭니다.

### 3-3. 메뉴 등록

메뉴는 **엔지니어 메뉴**로 등록됩니다. 엔지니어 권한(`user.ENGINEER_AUTH_YN = 'Y'`)이 있는 사용자에게만 보이고, 다른 사용자에게는 숨겨집니다. 권한 관리(`auth_menu_map`)에는 등록하지 않습니다.

1. 포털 DB 에 접속해 상위 메뉴 ID 와 엔지니어 권한 사용자를 확인합니다. DB 접속 정보는 `<props>` 의 `miso.db.url`, `miso.db.user`, `miso.db.password` 에 있습니다.

```sql
-- 상위 메뉴 '시스템 관리' 의 MENU_ID
SELECT MENU_ID, MENU_NM, P_MENU_ID, USE_YN FROM menu WHERE MENU_NM = '시스템 관리';
-- 엔지니어 권한 사용자 (없으면 사용할 계정에 부여)
SELECT USER_ID, USER_NM, AUTH_ID FROM user WHERE ENGINEER_AUTH_YN = 'Y';
```

2. `menu_insert.sql` 맨 위의 `@P_MENU_ID` 값을 위에서 확인한 값으로 수정합니다.

3. `menu`, `auth_menu_map` 테이블을 백업한 뒤 실행합니다.

```
mysqldump -u <계정> -p <DB명> menu auth_menu_map > menu_bak_YYMMDD.sql
mysql -u <계정> -p <DB명> < menu_insert.sql
```

   이미 등록돼 있으면 중복으로 들어가지 않고 엔지니어 메뉴로 바뀝니다. 마지막에 등록 결과와 엔지니어 권한 사용자가 출력됩니다.

4. 엔지니어 권한 사용자로 다시 로그인하면 `시스템 관리 > 시스템 백업` 메뉴가 보입니다.

### 3-4. 자동 백업 상시 실행 (권장)

자동 백업 스케줄러는 메뉴 화면이 처음 열릴 때 시작됩니다. WAS 재기동 후 메뉴를 열지 않아도 자동 백업이 실행되게 하려면 Tomcat `conf/web.xml` 의 jsp 서블릿 정의 아래에 다음을 추가하고 WAS 를 재기동합니다.

```xml
<servlet>
    <servlet-name>misoBackup</servlet-name>
    <jsp-file>/web/plugins/misoBackup/index.jsp</jsp-file>
    <load-on-startup>10</load-on-startup>
</servlet>
```

`conf/web.xml` 은 그 Tomcat 의 모든 웹앱에 적용됩니다. ROOT 외 웹앱이 함께 있으면 `<ROOT>/WEB-INF/web.xml` 에 추가합니다.

### 3-5. 설치 확인

1. `시스템 관리 > 시스템 백업` 메뉴에서 저장 위치가 표시되는지 확인합니다.
2. 백업 대상 `DB` 만 선택해 `백업 실행` 을 누르고, 완료 후 목록에 표시되는지 확인합니다.
3. 목록에서 다운로드가 되는지 확인합니다.

## 4. 사용

### 백업

- 백업 대상(DB / 웹앱 ROOT / 업로드 파일)을 선택하고 `백업 실행` 을 누릅니다. 진행률과 남은 시간이 표시됩니다.
- 백업마다 `backup.dir/YYYYMMDD_HHMMSS/` 폴더가 생성됩니다.

| 대상 | 내용 | 파일 |
|---|---|---|
| DB | 포털 DB 의 테이블·데이터·뷰·트리거·프로시저/함수 | `db.sql.gz` |
| 웹앱 ROOT | `backup.webapp.dir` 전체 | `webapps_ROOT.tar.gz` |
| 업로드 파일 | `backup.fileupload.dir` 와 `backup.editor.dir` | `upload_files.tar.gz` |

압축 파일 안의 경로는 설정 경로 기준입니다. 복구할 때도 같은 기준으로 현재 설정 경로에 풉니다.
- `webapps_ROOT.tar.gz` : 웹앱 안의 내용부터 (`WEB-INF/...`, `index.jsp` ...) → `backup.webapp.dir` 안
- `upload_files.tar.gz` : `fileupload/...` → `backup.fileupload.dir` 안, `editor/...` → `backup.editor.dir` 안

- DB 는 포털의 DB 연결을 그대로 사용하므로 비밀번호가 암호화(`ENC(...)`)돼 있어도 동작합니다.

### 복구

목록의 `복구` 버튼 → 복구 대상 선택 → 확인 순서로 진행합니다.

- `복구 전에 현재 상태를 먼저 백업` 은 기본 선택돼 있으며, 해제하지 않는 것을 권장합니다.
- DB : 백업에 있는 테이블·뷰·함수를 백업 시점으로 되돌립니다. 백업 이후 새로 만든 테이블은 그대로 남습니다.
- 업로드 파일 : 현재 설정된 경로(`backup.fileupload.dir`, `backup.editor.dir`)에 덮어씁니다. 서버를 옮겨 경로가 바뀌었어도 현재 경로에 풀리며, 복구 창에 `이전 경로 → 현재 경로` 가 표시됩니다. 백업 이후 새로 올린 파일은 그대로 남습니다.
- 웹앱 ROOT : WAS 를 종료 → 기존 웹앱 폴더를 `<Tomcat>/<폴더명>_before_restore_<시각>` 으로 이동 → 백업 압축을 `backup.webapp.dir` 에 해제 (백업 당시 폴더 이름이 달라도 됨) → `backup.restore.keep` 파일은 현재 것으로 되돌림 → WAS 기동 순서로 자동 처리합니다. 실패하면 기존 ROOT 로 되돌립니다. 재기동 중에는 화면이 대기 상태로 표시되고, 접속이 복구되면 결과가 표시됩니다.
  - `<Tomcat>/webapps/ROOT.war` 가 있는 서버는 기동 시 war 가 다시 배포되므로 ROOT 복구를 하지 않습니다.
  - `system.properties`(DB 접속 정보 등)와 namo `Config.xml` 은 기본으로 현재 서버 것을 유지합니다. 다른 서버별 설정 파일이 웹앱 안에 있으면 `backup.restore.keep` 에 추가합니다.
- 복구한 파일의 권한(rwx)은 백업 당시대로, 소유자·그룹은 복구 대상 폴더(업로드 폴더, 복구 전 웹앱 폴더)와 같게 맞춥니다. (WAS 를 root 로 기동한 경우. 일반 계정이면 그 계정 소유)
- 복구 결과는 화면의 `최근 복구` 와 `backup.dir/restore.log` 에 남습니다.

### 권한

엔지니어 권한(`user.ENGINEER_AUTH_YN = 'Y'`)이 있는 사용자만 메뉴가 보이고, 조회·다운로드·백업·삭제·복구를 모두 할 수 있습니다.
엔지니어 권한이 없으면 포털 권한 관리에서 메뉴를 열어 주더라도 화면과 모든 기능이 403 으로 차단됩니다.

- 백업 파일에는 DB 전체(사용자 정보 포함)와 DB 접속 정보가 들어 있으므로 엔지니어 권한은 최소 인원에게만 부여합니다.
- 다운로드·백업·삭제·복구 요청은 사용자 ID 와 접속 IP 가 WAS 로그(`catalina.out`)에 `misoBackup` 으로 기록됩니다.

## 5. 서버 구성별 참고

- **DB 분리** : 포털과 같은 DB 연결로 백업·복구하므로 DB 서버에 설치할 것은 없습니다. 포털 DB 계정에 다음 권한이 필요합니다.
  - 백업 : SELECT, SHOW VIEW, TRIGGER
  - 복구 : DROP, CREATE, ALTER, INSERT, CREATE VIEW, CREATE ROUTINE, TRIGGER
  - 바이너리 로그를 쓰는 DB 에서 SUPER 권한 없이 함수를 복구하면 `log_bin_trust_function_creators=1` 설정이 필요할 수 있습니다.
- **WEB 분리 (Apache/Nginx)** : `/web/plugins/misoBackup/index.jsp` 요청이 WAS 로 전달돼야 합니다. 웹서버가 `/web/*` 를 정적 파일로 직접 처리하면 화면이 열리지 않습니다. 큰 백업 파일을 내려받을 때 웹서버의 프록시 타임아웃·크기 제한도 확인합니다.
- **WAS 이중화** : 각 WAS 에서 따로 동작합니다.
  - `backup.dir` 이 WAS 로컬 디스크면 백업은 요청을 받은 WAS 에만 저장됩니다. 자동 백업은 한 WAS 에만 `backup.cron` 을 설정합니다.
  - `backup.dir` 이 공유 스토리지(NAS)면 자동 백업이 한 번만 실행됩니다.
  - 웹앱 ROOT 복구는 요청을 받은 WAS 하나만 처리하므로 다른 WAS 는 따로 복구합니다.

## 6. 서버 이전 (다른 서버로 옮기기)

1. 기존 서버에서 백업(DB, 업로드 파일)을 실행합니다.
2. 새 서버에 포털과 이 플러그인을 설치하고, `system.properties` 의 DB 접속 정보·`backup.webapp.dir`·`backup.fileupload.dir`·`backup.editor.dir` 이 **새 서버 경로**인지 확인합니다. (화면의 `백업 경로` 에 표시됩니다)
3. 기존 서버 `backup.dir` 의 백업 폴더(`YYYYMMDD_HHMMSS`)를 새 서버 `backup.dir` 아래로 복사합니다.
4. 새 서버 `시스템 백업` 메뉴에서 그 백업의 `복구` → 대상 선택 → 복구 창의 `복구 위치` 를 확인한 뒤 실행합니다. 웹앱도 복구하면 `system.properties` 등은 새 서버 것이 유지됩니다.
5. DB 를 복구하면 메뉴·권한도 기존 서버 상태가 되므로 다시 로그인합니다.

## 7. 업그레이드

새 zip 의 `misoBackup/` 폴더를 `<ROOT>/web/plugins/` 에 덮어씁니다 (`cp -r misoBackup <ROOT>/web/plugins/`). 재기동 없이 다음 요청부터 적용됩니다.

포털 war 를 새로 배포하면 `<ROOT>` 가 교체되어 플러그인이 지워질 수 있습니다. war 배포 후 3-1 을 다시 수행하거나, 포털 war 에 플러그인을 포함합니다(`src/main/webapp/web/plugins/misoBackup/`).

## 8. 제거

1. `menu_delete.sql` 을 실행합니다.
2. `<ROOT>/web/plugins/misoBackup/` 폴더를 삭제합니다.
3. `<props>` 의 `backup.*` 항목과 `conf/web.xml` 에 추가한 `misoBackup` 서블릿을 삭제하고 WAS 를 재기동합니다.
4. 백업 파일이 더 필요 없으면 `backup.dir` 을 삭제합니다.

## 9. 문제 해결

| 증상 | 확인 |
|---|---|
| 메뉴가 안 보임 | 로그인 계정의 `user.ENGINEER_AUTH_YN` 이 `Y` 인지 확인 후 다시 로그인. `menu_insert.sql` 결과의 `ENGINEER_YN`, `USE_YN` 이 `Y` 인지 확인 |
| 403 오류 | 엔지니어 권한이 없는 계정 (위와 같이 확인) |
| `backup.dir 을 설정하세요` 표시, 백업 버튼 비활성 | 3-2 설정 확인 |
| 백업 실패 | `backup.dir` 쓰기 권한과 디스크 여유 공간 확인. WAS 로그(`catalina.out`)의 `misoBackup` 메시지 확인 |
| 자동 백업이 안 됨 | `backup.cron` 형식 확인. WAS 재기동 후라면 3-4 설정 확인 |
| 화면이 안 열리거나 JSP 소스가 보임 | 웹서버가 해당 경로를 WAS 로 넘기는지 확인 (5. WEB 분리) |
| ROOT 복구 결과 | `backup.dir/.restore/restore_root.log` 확인 |

====================================================================

## 요약 (설치 순서)

1. `misoBackup/` 폴더를 `<ROOT>/web/plugins/` 에 복사
```
cp -r misoBackup <ROOT>/web/plugins/
```
2. `system.properties` 백업 후 맨 아래에 추가 (경로는 서버에 맞게 수정)
```
# misoBackup plugin
backup.dir=/data/miso/backup
backup.webapp.dir=/data/miso/webapps
backup.editor.dir=/data/miso/editorImage
backup.fileupload.dir=/data/miso/fileUpload
backup.targets=db,root,upload
backup.keep=10
backup.cron=0 1 * * *
```
3. DB 에서 '시스템 관리' MENU_ID 와 엔지니어 권한 사용자(`user.ENGINEER_AUTH_YN = 'Y'`) 확인
4. `menu_insert.sql` 맨 위 `@P_MENU_ID` 수정 → `menu`, `auth_menu_map` 백업 → 실행
5. (권장) Tomcat `conf/web.xml` 의 jsp 서블릿 정의 아래에 추가 → WAS 재기동
```xml
<servlet>
    <servlet-name>misoBackup</servlet-name>
    <jsp-file>/web/plugins/misoBackup/index.jsp</jsp-file>
    <load-on-startup>10</load-on-startup>
</servlet>
```
6. 엔지니어 권한 계정으로 다시 로그인 → `시스템 관리 > 시스템 백업` 에서 DB 백업 실행·다운로드로 확인
