-- misoBackup 플러그인 메뉴 삭제 (제거 시)
SET @id = (SELECT MENU_ID FROM menu WHERE MENU_LINK_URL = '/web/plugins/misoBackup/index.jsp' ORDER BY MENU_ID LIMIT 1);
DELETE FROM auth_menu_map WHERE MENU_ID = @id;
DELETE FROM menu WHERE MENU_ID = @id;
