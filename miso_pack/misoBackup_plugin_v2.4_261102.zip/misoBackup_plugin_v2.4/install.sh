#!/bin/bash
# misoBackup 플러그인 설치 : ./install.sh <Tomcat 경로>     예) ./install.sh /data/miso/tomcat
#   1) server.xml 에서 ROOT 웹앱 폴더를 찾음
#   2) DB 접속 확인 (miso.db.url 이 안 되면 db_ip/port/name/id/pw 를 받아 접속 테스트 후 backup.db_* 로 저장, 실패하면 종료)
#   3) system.properties 에 backup.* 중 없는 항목만 추가 (값은 물어봄, Enter = 기본값)
#   4) 메뉴 등록 : 사용 중인 중메뉴 시스템관리 아래에 자동 (못 찾을 때만 번호로 선택, '시스템 백업' 이미 있으면 건너뜀)
#   5) Tomcat conf/web.xml 에 load-on-startup 등록 (이미 있으면 건너뜀)
#   6) WAS 가 systemd 서비스이고 일반 계정으로 돌면 웹앱 복구 때 재기동되도록 KillMode=process drop-in + sudo systemctl stop/start 허용
#   7) misoBackup/ 를 <웹앱>/web/plugins/ 에 복사 (기존 플러그인은 Tomcat 옆으로 백업)
# 2~6 은 먼저 물어보기만 하고, 마지막에 바뀔 내용을 모아 보여준 뒤 [Y] 적용 / 다시 입력 / [N] 취소 를 받음 (Y 전에는 변경 없음)
# 바꾸는 파일은 <파일>.bak_YYMMDD 로 먼저 백업. WAS 재기동은 하지 않음.
HERE=$(cd "$(dirname "$0")" && pwd)
[ -n "$1" ] || { echo "사용법 : $0 <Tomcat 경로>"; exit 1; }
TOMCAT=$(cd "$1" 2>/dev/null && pwd) || { echo "Tomcat 경로가 없습니다 : $1"; exit 1; }
[ -f "$TOMCAT/conf/server.xml" ] || { echo "$TOMCAT/conf/server.xml 이 없습니다. Tomcat 경로를 확인하세요."; exit 1; }
SRC=$HERE/misoBackup
JAR=$SRC/lib/misoBackup-core.jar
[ -f "$JAR" ] || { echo "$JAR 이 없습니다. zip 을 그대로 푼 폴더에서 실행하세요."; exit 1; }

# 소유자 : 실행 중인 Tomcat 프로세스 계정 → 없으면 Tomcat conf 폴더 소유자. 만들거나 고친 파일·폴더를 모두 이 계정으로 맞춤
PID=$(pgrep -f -- "-Dcatalina.(base|home)=$TOMCAT/?( |$)" | head -1)
OWNER=${PID:+$(ps -o user= -p "$PID" | tr -d ' ')}
[ -n "$OWNER" ] || OWNER=$(stat -c %U "$TOMCAT/conf")
GROUP=$(id -gn "$OWNER" 2>/dev/null) || GROUP=$(stat -c %G "$TOMCAT/conf")

# java : Tomcat 이 기동할 때와 같은 방식으로 찾음
#   1) 실행 중인 그 Tomcat 의 java
#   2) 로그인 환경 파일(/etc/environment, /etc/profile(.d), Tomcat 계정·현재 계정의 ~/.bash_profile 등)에 적힌 JAVA_HOME·JRE_HOME
#      → catalina.sh 에 적힌 JAVA_HOME → setenv.sh 실행
#      → JRE_HOME, 없으면 JAVA_HOME, 둘 다 없으면 PATH 의 java (Tomcat setclasspath.sh 규칙)
#      (로그인 셸을 직접 띄우지 않음 : 접속 기록용 profile 이 exec script 하는 서버가 있음)
#   3) Tomcat 옆 java*/jdk*/jre* 폴더   4) 직접 입력
javaof() {	# JAVA_HOME 이든 java 실행 파일 경로든 받아서 java 실행 파일로
	local p=${1%/}
	[ -n "$p" ] || return 1
	for j in "$p" "$p/bin/java" "$p/jre/bin/java"; do [ -f "$j" ] && [ -x "$j" ] && { readlink -f "$j"; return 0; }; done
	return 1
}
envval() {	# envval <변수> <파일...> : 파일들에서 마지막으로 적힌 값 ($ 가 들어간 값은 제외)
	local k=$1; shift
	sed -n "s/^[[:space:]]*\(export[[:space:]]\{1,\}\)\{0,1\}$k=[\"']\{0,1\}\([^\"' ;]*\).*/\2/p" "$@" 2>/dev/null | grep -v '\$' | tail -1
}
FROM=
if [ -n "$PID" ]; then JAVA=$(javaof "$(readlink -f /proc/$PID/exe 2>/dev/null)") && FROM="실행 중인 Tomcat"; fi
if [ -z "$FROM" ]; then
	PROFILES=(/etc/environment /etc/profile /etc/profile.d/*.sh /etc/bashrc)
	for h in "$(getent passwd "$OWNER" | cut -d: -f6)" "$HOME"; do
		[ -n "$h" ] && PROFILES+=("$h/.bash_profile" "$h/.bash_login" "$h/.profile" "$h/.bashrc")
	done
	JH=$(envval JAVA_HOME "${PROFILES[@]}"); JH=${JH:-$JAVA_HOME}
	RH=$(envval JRE_HOME "${PROFILES[@]}"); RH=${RH:-$JRE_HOME}
	v=$(envval JAVA_HOME "$TOMCAT/bin/catalina.sh"); [ -n "$v" ] && JH=$v
	R=$(JAVA_HOME=$JH JRE_HOME=$RH CATALINA_HOME=$TOMCAT CATALINA_BASE=$TOMCAT timeout 20 bash -c '
		[ -r "$CATALINA_BASE/bin/setenv.sh" ] && . "$CATALINA_BASE/bin/setenv.sh" >/dev/null 2>&1
		[ -z "$JRE_HOME" ] && JRE_HOME=$JAVA_HOME
		echo
		if [ -n "$JRE_HOME" ]; then echo "$JRE_HOME/bin/java"; else command -v java; fi' </dev/null 2>/dev/null | tail -1)
	JAVA=$(javaof "$R") && FROM="환경 파일 + Tomcat 설정"
fi
if [ -z "$FROM" ]; then
	for d in "$(dirname "$TOMCAT")"/java* "$(dirname "$TOMCAT")"/jdk* "$(dirname "$TOMCAT")"/jre*; do
		JAVA=$(javaof "$d") && FROM="Tomcat 옆 폴더" && break
	done
fi
while [ -z "$FROM" ]; do
	read -r -p "java 를 찾지 못했습니다. JAVA_HOME 또는 java 경로를 입력하세요 (빈 값 = 종료) : " v || exit 1
	[ -n "$v" ] || exit 1
	JAVA=$(javaof "$v") && FROM="직접 입력" || echo "  $v 에서 java 를 찾을 수 없습니다."
done
echo "java   : $JAVA ($FROM)"
echo "소유자 : $OWNER:$GROUP ($([ -n "$PID" ] && echo "실행 중인 Tomcat 계정" || echo "Tomcat conf 폴더 소유자"))"

WEBAPP=$("$JAVA" -cp "$JAR" misobackup.Installer find "$TOMCAT") || exit 1
echo "웹앱   : $WEBAPP"

# 1~5 : DB 확인(실패하면 여기서 종료) → system.properties → 메뉴 → web.xml → WAS 서비스
#        JDBC 드라이버는 웹앱 WEB-INF/lib 의 것을 씀 (mysql 클라이언트 불필요)
CP=$JAR
for j in "$WEBAPP"/WEB-INF/lib/*.jar; do case "${j##*/}" in *mariadb*|*mysql*) CP=$CP:$j;; esac; done
"$JAVA" -DmisoBackup.owner="$OWNER:$GROUP" -DmisoBackup.pid="$PID" -cp "$CP" misobackup.Installer setup "$TOMCAT" "$WEBAPP" || exit $?

# 5. 플러그인 복사 (웹앱과 같은 소유자로)
DST=$WEBAPP/web/plugins/misoBackup
echo; echo "== 6. 플러그인 복사 ($DST)"
if [ -d "$DST" ]; then
	BAK=$(dirname "$TOMCAT")/misoBackup_plugin_bak_$(date +%y%m%d_%H%M%S)
	cp -a "$DST" "$BAK" && echo "  기존 플러그인 백업 : $BAK" || exit 1
fi
for d in "$WEBAPP/web" "$WEBAPP/web/plugins" "$DST"; do	# 없는 폴더는 만들고 Tomcat 계정 소유로
	[ -d "$d" ] || { mkdir "$d" && [ "$(id -u)" = 0 ] && chown "$OWNER:$GROUP" "$d"; } || exit 1
done
cp -r "$SRC/." "$DST/" || exit 1
[ "$(id -u)" = 0 ] && chown -R "$OWNER:$GROUP" "$DST"
echo "  복사 완료"
echo
echo "  WAS 를 재기동해야 web.xml 설정이 적용됩니다. (재기동은 하지 않았습니다)"
echo "  엔지니어 권한 계정으로 로그인 → 시스템 관리 > 시스템 백업 에서 확인하세요."
