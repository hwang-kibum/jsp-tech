# misoBackup 플러그인 (v2.4)

포털 `시스템 관리 > 시스템 백업` 메뉴에서 DB, 웹앱(ROOT), 업로드 파일을 백업하고 복구하는 플러그인입니다.

# 요약

## 설치

1. zip 을 서버에 올려 풀고, 그 폴더에서 Tomcat 경로를 주고 root 로 실행합니다.
```
unzip misoBackup_plugin_v2.4_*.zip
cd misoBackup_plugin_v2.4
./install.sh /data/miso/tomcat
```
2. 화면의 질문에 답합니다. 대부분 `Enter`(자동으로 찾은 기본값)로 넘어갑니다.
   - DB 접속이 안 되면 `db_ip`, `db_port`, `db_name`, `db_id`, `db_pw` 를 묻고, 그래도 안 되면 아무것도 바꾸지 않고 종료합니다.
   - 폴더가 없거나 틀리면 `[1] 폴더 만들기` / `[2] 경로 다시 입력` 을 묻습니다.
3. 마지막 `최종 확인` 화면에서 바뀔 내용을 확인하고 `Y` 를 누릅니다. (`Y` 전에는 아무것도 바뀌지 않습니다)
4. WAS 를 재기동합니다. (자동 백업 스케줄러를 기동 시 시작하기 위해)
5. 엔지니어 권한(`user.ENGINEER_AUTH_YN = 'Y'`) 계정으로 로그인 → `시스템 관리 > 시스템 백업` → `DB` 만 골라 `백업 실행` → 목록·다운로드 확인

## 운용

| 할 일 | 방법 |
|---|---|
| 수동 백업 | 메뉴에서 대상(DB / 웹앱 ROOT / 업로드 파일 / 전달용 DB) 선택 → `백업 실행` |
| 전달용 DB | 외부 전달용 DB 덤프. log 테이블 데이터 제외, 이메일·전화번호·IP 마스킹 (6-1) |
| 자동 백업 | `system.properties` 의 `backup.cron`(기본 매일 01:00), `backup.targets`, `backup.keep`(기본 10개) |
| 다운로드 | 목록에서 백업 파일 다운로드 |
| 복구 | 목록의 `복구` → 대상 선택 → `복구 전에 현재 상태를 먼저 백업`(기본 선택, 유지 권장) → 확인. 웹앱 ROOT 복구는 WAS 가 자동 재기동됩니다 |
| 결과 확인 | 화면의 `최근 복구`, `backup.dir/restore.log`, WAS 로그(`catalina.out`)의 `misoBackup` |
| 서버 이전 | 기존 서버 백업 폴더(`YYYYMMDD_HHMMSS`)를 새 서버 `backup.dir` 에 복사 → 새 서버 메뉴에서 복구 (6장) |
| 업그레이드 | 새 zip 으로 `./install.sh` 다시 실행 (이미 있는 설정·메뉴·web.xml 은 건너뜀) |

- 백업 파일에는 DB 전체와 접속 정보가 들어 있습니다. 엔지니어 권한은 최소 인원에게만 줍니다.
- 웹앱 복구 때 `system.properties`(고객사 IP·DB 정보), namo `Config.xml`, 이 플러그인 폴더는 현재 서버 것을 그대로 유지합니다.

====================================================================

# 상세

아래에서 `<Tomcat>` 은 Tomcat 경로, `<ROOT>` 는 웹앱 폴더(`server.xml` 의 `<Context path="/" docBase>`, 없으면 `<Tomcat>/webapps/ROOT`), `<props>` 는 `<ROOT>/WEB-INF/classes/properties/system.properties` 입니다.

## 1. 구성

```
misoBackup_plugin_v2.4/
├── misoBackup/                  ← <ROOT>/web/plugins/ 에 들어가는 폴더
│   ├── index.jsp                  백업 화면
│   └── lib/misoBackup-core.jar    백업 엔진 (DB 덤프, 압축, 자동 백업, 설치기)
├── install.sh                   자동 설치
├── menu_insert.sql              메뉴 등록 SQL (수동 설치용)
├── menu_delete.sql              메뉴 삭제 SQL (제거용)
└── README.md
```

문서·SQL·install.sh 는 웹 경로에 노출되지 않도록 `misoBackup/` 밖에 둡니다.

## 2. 요구 사항

- 포털 WAS : Tomcat 9 (Java 8 이상) 또는 Tomcat 11 (Java 17 이상)
- DB : MariaDB / MySQL (포털이 사용하는 DB)
- mysqldump, tar, mysql 클라이언트 등은 필요 없습니다. WAS 의 Java 와 웹앱 `WEB-INF/lib` 의 JDBC 드라이버만 씁니다.
- install.sh 와 웹앱 ROOT 복구는 Linux(bash) 에서만 동작합니다.
- 백업 저장 공간 : (DB + 웹앱 + 업로드 파일 크기) × 보관 개수

## 3. 자동 설치 (install.sh)

```
./install.sh <Tomcat 경로>
```

처리 순서는 아래와 같습니다. 2 ~ 5 는 먼저 물어보기만 하고, 6 의 최종 확인에서 `Y` 를 눌러야 적용됩니다.

### 3-1. 준비 (자동)

- **java** : Tomcat 이 기동할 때와 같은 방식으로 찾습니다. 실행 중인 그 Tomcat 의 java → 로그인 환경 파일(`/etc/profile`, `/etc/profile.d/*.sh`, Tomcat 계정·root 의 `~/.bash_profile` 등)의 `JAVA_HOME`·`JRE_HOME` → `catalina.sh` 에 적힌 `JAVA_HOME` → `setenv.sh` → `PATH` 의 java → Tomcat 옆 `java*`·`jdk*`·`jre*` 폴더 → 못 찾으면 경로를 입력받음
- **웹앱 폴더** : `conf/server.xml` 의 `/` Context docBase → `conf/Catalina/<host>/ROOT.xml` → `<appBase>/ROOT`
- **소유자** : 실행 중인 Tomcat 프로세스 계정, Tomcat 이 꺼져 있으면 `conf` 폴더 소유자. 그룹은 그 계정의 기본 그룹.
  root 로 실행해도 만들거나 고친 폴더·파일(아래 모두)은 이 계정 소유로 바꿉니다.

### 3-2. DB 접속 확인

1. `<props>` 의 `miso.db.url`, `miso.db.user`, `miso.db.password` 로 접속합니다.
2. 실패하면 `backup.db_*` 값이 있을 때 그것으로 접속합니다.
3. 그래도 실패하면 접속 정보를 입력받습니다. (기본값은 `miso.db.url` 에서 읽은 값)
```
db_ip [10.0.0.10] :
db_port [3306] :
db_name [miso] :
db_id [miso] :
db_pw :
```
4. 접속되면 적용할 때 `<props>` 에 다음으로 저장합니다. 백업·복구도 포털 DB 접속이 안 될 때 이 값으로 접속합니다.
```
backup.db_ip=10.0.0.10
backup.db_port=3306
backup.db_name=miso
backup.db_id=miso
backup.db_pw=B64:bWlzbzEyMzQ=
```
   - 비밀번호는 입력할 때 화면에 보이지 않고, `B64:<base64>` 로 인코딩해 저장합니다. 암호화가 아니라 눈에 바로 보이지 않게 하는 정도이므로 파일 권한 관리는 그대로 필요합니다.
   - 직접 적을 때는 평문도 동작합니다. 인코딩 값은 `echo -n '비밀번호' | base64` 결과 앞에 `B64:` 를 붙입니다.
5. 입력한 값으로도 접속이 안 되면 **아무것도 바꾸지 않고 종료**합니다. (종료 코드 2) 접속 정보를 확인한 뒤 다시 실행합니다.

### 3-3. system.properties

`backup.*` 중 **없는 항목만** 묻습니다. `Enter` 는 [ ] 안의 기본값입니다.

| 항목 | 기본값 (자동으로 찾는 순서) |
|---|---|
| `backup.dir` | `<Tomcat 상위 폴더>/backup` |
| `backup.webapp.dir` | 묻지 않음. 3-1 에서 찾은 실제 웹앱 폴더 |
| `backup.fileupload.dir` | `fileUpload.dir` → `server.xml` 의 path 에 `upload` 가 든 Context → 웹앱·Tomcat 옆 `fileUpload*` 폴더 |
| `backup.editor.dir` | `server.xml` 의 path 에 `editor` 가 든 Context → namo `Config.xml` 의 `ImageSavePath` → 웹앱·Tomcat 옆 `editorImage*` 폴더 |
| `backup.targets` | `DB,webapps,Upload_files` |
| `backup.keep` | `10` |
| `backup.cron` | `0 1 * * *` |

폴더 확인 (`backup.dir`, `backup.fileupload.dir`, `backup.editor.dir`)

- 입력한 폴더가 없으면 다시 묻습니다.
```
! 폴더가 없습니다 : /data/miso/backup
[1] 폴더 만들기  [2] 경로 다시 입력  [0] 넣지 않음
```
  - `1` : 적용할 때 만듭니다. (Tomcat 계정 소유, `backup.dir` 은 700)
  - `2` : 다시 입력받고 같은 확인을 반복합니다.
  - `0` : 업로드·에디터 폴더만 가능. 넣지 않으면 그 파일은 백업·복구하지 않습니다.
- 이미 있는 값도 폴더가 없으면 같은 방식으로 묻습니다. `Enter` 는 그대로 둡니다.
- `backup.webapp.dir` 이 이미 있는데 실제 웹앱 폴더와 다르면 묻지 않고 실제 경로로 바꿉니다.

### 3-4. 메뉴

- 이미 `시스템 백업` 메뉴(`MENU_LINK_URL = /web/plugins/misoBackup/index.jsp`)가 있으면 건너뜁니다.
- 메뉴 구조는 `miso_portal.sh menu` 와 같은 기준으로 읽습니다.
  - `MENU_GROUP_ID` 가 있는 포털 : 대메뉴(`MENU_ID = MENU_GROUP_ID`) > 중메뉴(`MENU_GROUP_ID`) > 소메뉴(`P_MENU_ID`)
  - 구버전 포털 : `P_MENU_ID` 만으로 구성
- 사용 중(`USE_YN = 'Y'`)인 중메뉴 `시스템관리`(띄어쓰기 무시, 구버전은 최상위)가 하나면 묻지 않고 그 아래 소메뉴로 등록합니다.
- 없거나 여러 개일 때만 번호로 내려가며 위치를 고릅니다.
```
 15. 시스템 관리 [Y]
선택 : 15
  1. 시스템 관리 [Y]
선택 : 1
[S] 이 메뉴 아래에 등록
[0] 뒤로
```
- 등록 값 : `시스템 백업` / `System Backup`, 순서는 같은 상위 메뉴의 마지막 다음, `USE_YN = 'Y'`, `ENGINEER_YN = 'Y'`(엔지니어 메뉴), `auth_menu_map` 은 등록하지 않음. menu 테이블에 있는 열만 씁니다.

### 3-5. Tomcat conf/web.xml

자동 백업 스케줄러는 메뉴 화면을 처음 열 때 시작됩니다. WAS 재기동 후 메뉴를 열지 않아도 자동 백업이 돌도록 jsp 서블릿 정의 바로 아래에 다음을 넣습니다. 이미 있으면 건너뜁니다.

```xml
<servlet>
    <servlet-name>misoBackup</servlet-name>
    <jsp-file>/web/plugins/misoBackup/index.jsp</jsp-file>
    <load-on-startup>10</load-on-startup>
</servlet>
```

- `<jsp-file>` 은 웹앱 기준 경로라 웹앱 위치(docBase)와 상관없이 그대로 씁니다.
- `conf/web.xml` 은 그 Tomcat 의 모든 웹앱에 적용됩니다. ROOT 외 웹앱이 있으면 그 웹앱 기동 로그에 파일 없음 오류가 남을 수 있습니다(기동은 정상).
- 적용하려면 WAS 재기동이 필요합니다.

### 3-6. WAS 실행 방식 (웹앱 복구 때 재기동)

웹앱 ROOT 복구는 WAS 를 내렸다 올립니다. Tomcat 을 어떻게 띄웠는지에 따라 처리가 다릅니다. (실행 중이면 그 프로세스로, 꺼져 있으면 `ExecStart` 에 이 Tomcat 경로가 있는 서비스 파일로 판단)

| 실행 방식 | 복구 때 재기동 | install.sh 가 추가하는 것 |
|---|---|---|
| 수동 (`startup.sh`) | `shutdown.sh` → `startup.sh` (Tomcat 계정으로) | 없음 |
| systemd 서비스, root 실행 | `systemctl stop/start <서비스>`, 복구 작업은 `systemd-run` 으로 서비스 밖에서 실행 | 없음 |
| systemd 서비스, 일반 계정 실행 (`User=`) | `sudo systemctl stop/start <서비스>` | 아래 2개 |

일반 계정 서비스일 때 추가하는 것 (root 소유, 이미 되어 있으면 건너뜀)

```
# /etc/systemd/system/<서비스>.d/misobackup.conf   (추가 후 systemctl daemon-reload)
[Service]
KillMode=process

# /etc/sudoers.d/misobackup   (visudo 검사 후 등록, 권한 440)
<계정> ALL=(root) NOPASSWD: /usr/bin/systemctl stop <서비스>, /usr/bin/systemctl start <서비스>
```

- `KillMode=process` : 서비스가 내려갈 때 Tomcat 만 종료하고 복구 작업은 남깁니다. 없으면 WAS 가 내려가는 순간 복구 작업도 같이 종료되어 웹앱이 반쯤 바뀐 채 WAS 가 꺼져 있게 됩니다.
- sudo 는 그 서비스의 stop/start 두 명령만 허용합니다.
- 이 설정이 없는 상태에서 웹앱 복구를 누르면 아무것도 바꾸지 않고 `install.sh 를 다시 실행` 하라는 오류를 표시합니다.
- 서비스 재기동 없이 바로 적용됩니다.

### 3-7. 최종 확인

```
== 최종 확인 (아직 아무것도 바뀌지 않았습니다)
  [폴더 만들기]
    /data/miso/backup  (backup.dir)
  [system.properties] /data/miso/webapps/WEB-INF/classes/properties/system.properties
    추가 backup.dir=/data/miso/backup
    추가 backup.webapp.dir=/data/miso/webapps
    ...
  [메뉴]
    시스템 관리 > 시스템 관리 > 시스템 백업  (상위 MENU_ID 9)
  [web.xml] /data/miso/tomcat/conf/web.xml
    misoBackup load-on-startup 추가 (jsp 서블릿 아래, 재기동 필요)
  [WAS 서비스]
    systemd 서비스 tomcat.service (miso 계정 실행) : 복구 때 sudo systemctl 로 재기동
    추가 /etc/systemd/system/tomcat.service.d/misobackup.conf (KillMode=process)
    추가 /etc/sudoers.d/misobackup : miso ALL=(root) NOPASSWD: /usr/bin/systemctl stop tomcat.service, /usr/bin/systemctl start tomcat.service
  [소유자]
    miso:miso (만들거나 고친 폴더·파일, 플러그인 모두)
  [플러그인]
    /data/miso/webapps/web/plugins/misoBackup 에 복사 (기존 것은 Tomcat 옆으로 백업)

  [Y] 적용  [1] system.properties 다시 입력  [2] 메뉴 위치 다시 선택  [N] 취소
```

- `Y` : 적용 → 플러그인 복사 → 결과 출력
- `1` : system.properties 항목을 다시 묻습니다. (앞에서 입력한 값이 기본값)
- `2` : 메뉴 위치를 번호로 다시 고릅니다.
- `N` : 아무것도 바꾸지 않고 종료합니다. (종료 코드 3)

적용할 때

- 바꾸는 파일은 먼저 `<파일>.bak_YYMMDD` (같은 날 여러 번이면 `_1`, `_2` ...) 로 백업합니다.
- 기존 플러그인 폴더는 `<Tomcat 상위 폴더>/misoBackup_plugin_bak_<시각>` 으로 백업한 뒤 덮어씁니다. (웹 경로 밖)
- WAS 재기동은 하지 않습니다.

## 4. 수동 설치

install.sh 를 쓸 수 없을 때의 순서입니다.

1. 플러그인 복사 후 Tomcat 계정 소유로 맞춥니다.
```
cp -r misoBackup <ROOT>/web/plugins/
chown -R <Tomcat 계정>:<그룹> <ROOT>/web/plugins/misoBackup
```
2. `<props>` 를 백업(`cp system.properties system.properties.bak_YYMMDD`)하고 맨 아래에 추가합니다. (경로는 서버에 맞게)
```
# misoBackup plugin
backup.dir=/data/miso/backup
backup.webapp.dir=/data/miso/webapps
backup.fileupload.dir=/data/miso/fileUpload
backup.editor.dir=/data/miso/editorImage
backup.targets=DB,webapps,Upload_files
backup.keep=10
backup.cron=0 1 * * *
```
3. 포털 DB 에서 상위 메뉴와 엔지니어 권한 사용자를 확인합니다.
```sql
SELECT MENU_ID, MENU_NM, MENU_GROUP_ID, P_MENU_ID, USE_YN FROM menu WHERE REPLACE(MENU_NM, ' ', '') = '시스템관리';
SELECT USER_ID, USER_NM FROM user WHERE ENGINEER_AUTH_YN = 'Y';
```
4. `menu_insert.sql` 맨 위 `@P_MENU_ID` 를 중메뉴 `시스템관리` 의 MENU_ID 로 고치고, `menu`·`auth_menu_map` 을 백업한 뒤 실행합니다.
   menu 테이블에 `MENU_GROUP_ID`, `LINKAGE_YN` 열이 없는 구버전 포털은 INSERT 문에서 두 열과 값을 빼고 실행합니다.
5. Tomcat `conf/web.xml` 에 3-5 의 서블릿을 추가하고 WAS 를 재기동합니다.
6. WAS 가 일반 계정 systemd 서비스면 3-6 의 두 파일을 추가하고 `systemctl daemon-reload` 합니다.

## 5. 설정 (system.properties)

| 항목 | 설명 | 없을 때 |
|---|---|---|
| `backup.dir` | 백업 저장 경로. 운영 디스크와 다른 디스크(NAS) 권장, 웹 경로(`<ROOT>` 아래) 금지 | 백업 불가 |
| `backup.webapp.dir` | 웹앱 ROOT 경로. 실제 서비스 중인 웹앱과 다르면 오류로 막습니다 | 웹앱 백업·복구 불가 |
| `backup.fileupload.dir` | 첨부 업로드 경로 (포털 `fileUpload.dir` 과 같은 곳) | 첨부 백업·복구 안 함 |
| `backup.editor.dir` | 에디터 이미지 경로 (`/editorImage` Context docBase, namo `ImageSavePath` 와 같은 곳) | 에디터 이미지 백업·복구 안 함 |
| `backup.cron` | 자동 백업 일정. `분 시 일 월 요일` (예: `0 1 * * *` = 매일 01:00) | 자동 백업 안 함 |
| `backup.targets` | 자동 백업 대상. `DB`(DB 덤프), `webapps`(웹앱 ROOT), `Upload_files`(업로드 파일), `DB_transfer`(전달용 DB) 쉼표 구분. 예전 이름 `db`, `root`, `upload` 도 됨 | `DB,webapps,Upload_files` |
| `backup.keep` | 보관 개수 (수동·자동 합산). 넘으면 오래된 것부터 삭제 | 10 |
| `backup.restore.keep` | 웹앱 복구 때 현재 파일을 유지할 웹앱 안 경로 (쉼표 구분) | `WEB-INF/classes/properties/system.properties,web/plugins/namo/config/xmls/Config.xml` |
| `backup.tomcat.stop` / `backup.tomcat.start` | 웹앱 복구 때 WAS 종료/기동 명령. 보통 비워 둠 (3-6 처럼 자동으로 정함) | 3-6 표 |
| `backup.db_ip` / `_port` / `_name` / `_id` / `_pw` | 포털 DB 접속이 안 될 때 쓰는 대체 접속 정보 (install.sh 가 저장, `_pw` 는 `B64:` 인코딩 또는 평문) | 대체 접속 안 함 |

- 설정은 저장 즉시 반영됩니다. (재기동 불필요)
- 백업 폴더는 700, 백업 파일은 600 (WAS 실행 계정만 접근) 으로 만듭니다.

## 6. 사용

### 6-1. 백업

- 대상을 고르고 `백업 실행` → 진행률·남은 시간이 표시됩니다.
- 백업마다 `backup.dir/YYYYMMDD_HHMMSS/` 폴더가 생깁니다. 이 폴더가 곧 기록이며, 별도 DB 저장은 없습니다.

| 대상 | 내용 | 파일 |
|---|---|---|
| DB | 테이블·데이터·뷰·트리거·프로시저/함수 | `db.sql.gz` |
| 웹앱 ROOT | `backup.webapp.dir` 전체 | `webapps_ROOT.tar.gz` |
| 업로드 파일 | `backup.fileupload.dir`, `backup.editor.dir` | `upload_files.tar.gz` |
| 전달용 DB | DB 와 같되 아래 규칙 적용 (기본 선택 해제, 복구 대상 아님) | `db_transfer.sql.gz` |

- 압축 안 경로 : `webapps_ROOT.tar.gz` 는 웹앱 안 내용부터(`WEB-INF/...`), `upload_files.tar.gz` 는 `fileupload/...`, `editor/...`. 복구도 같은 기준으로 **현재 설정 경로**에 풉니다.
- DB 는 포털의 DB 연결(커넥션 풀)을 그대로 쓰므로 비밀번호가 암호화(`ENC(...)`)돼 있어도 동작합니다. 포털 DB 연결이 실패하면 `backup.db_*` 로 다시 접속합니다.
- 백업 SQL 에는 스키마 이름(`USE`, `CREATE DATABASE`, `스키마.테이블`)이 없습니다. 스키마 이름이 다른 DB 에도 복구됩니다.
- 전달용 DB 규칙 (외부 전달용, 기존 DB 백업은 그대로)
  - 이름이 `log` / `logs` 로 끝나는 테이블(대소문자 무시)은 구조만 넣고 데이터는 뺍니다. 백업할 때마다 이름으로 판단하므로 새로 생긴 log 테이블도 자동 제외됩니다.
  - 문자열 컬럼 값 안의 이메일·전화번호·IP 를 백업하면서 마스킹합니다. 원본 DB 는 바뀌지 않습니다.

| 종류 | 예 | 결과 |
|---|---|---|
| 이메일 | `admin@jiran.com` | `ad***@jiran.com` |
| 이메일(HTML 본문 `&#64;` 포함) | `lsm97&#64;naver.com` | `ls***&#64;naver.com` |
| 번호 형태 (전화·주민·카드·계좌 등, 숫자 묶음이 `-` `.` 공백 `( )` 로 이어진 7~16자리) | `010-1234-5678`, `01012345678`, `(123) 112-3222`, `900101-1234567`, `1234-5678-9012-3456`, `4150-437` | `010-****-5678`, `010****5678`, `(123) ***-3222`, `900101-*******`, `1234-****-****-3456`, `****-437` |
| IP | `10.52.9.226`, `http://10.52.9.226:82` | `10.52.*.*`, `http://10.52.*.*:82` |

  - 날짜(`2026-10-30`)·시간·문서번호(`20260929-0001`, `2026-0001`)·구분자 없는 숫자 ID(붙여 쓴 번호는 01x·02·031~064·070·080·050x 로 시작하는 9~12자리만 마스킹, 예 `0212345678` → `02****5678`)·소수·금액(`1,234,567`)·브라우저 버전(`Chrome/154.0.0.0`)은 바꾸지 않습니다.
  - 결과는 `backup.properties` 의 `transfer.logTables`(제외 테이블 수), `transfer.masked`(종류별 마스킹 수)에 남습니다.
  - 마스킹 후 값이 같아질 수 있어, 이메일 등에 UNIQUE 키가 있는 테이블은 받는 쪽에서 넣을 때 중복 오류가 날 수 있습니다.

### 6-2. 복구

목록의 `복구` → 대상 선택 → 확인.

- `복구 전에 현재 상태를 먼저 백업` 은 기본 선택입니다. 해제하지 않는 것을 권장합니다.
- **DB** : 백업에 있는 테이블·뷰·함수를 백업 시점으로 되돌립니다. 백업 이후 새로 만든 테이블은 남습니다.
  - 그 백업에 `시스템 백업` 메뉴가 없으면(플러그인 설치 전 백업) 복구 전 메뉴 값으로 다시 넣고, 있으면 엔지니어 메뉴 여부만 복구 전대로 맞춥니다.
- **업로드 파일** : 현재 설정 경로에 덮어씁니다. 경로가 바뀌었으면 복구 창에 `이전 경로 → 현재 경로` 가 표시됩니다. 백업 이후 올린 파일은 남습니다.
- **웹앱 ROOT** : 다음을 자동으로 처리합니다. 실패하면 기존 웹앱으로 되돌립니다.
  1. WAS 종료 (수동 기동이면 `shutdown.sh`, systemd 서비스면 `systemctl stop`, 3-6 참고)
  2. 현재 웹앱 폴더를 `<Tomcat>/<폴더명>_before_restore_<시각>` 으로 이동 (가장 최근 1개만 남김)
  3. 백업을 `backup.webapp.dir` 에 해제
  4. 현재 서버 것 유지 : `backup.restore.keep` 파일(`system.properties`, namo `Config.xml`)과 이 플러그인 폴더
  5. 백업에 든 설정 파일이 현재와 다르면 비교용으로 `<파일명>.from_backup_<백업 이름>` 으로 옆에 남김 (값은 쓰이지 않음)
  6. JSP 작업 폴더 삭제 → WAS 기동 (기동 명령이 실패하면 `restore.log` 에 `WAS 기동 실패` 로 남음 → 직접 기동)
  - 재기동 중에는 화면이 대기 상태로 표시되고, 접속되면 결과가 표시됩니다.
  - `<Tomcat>/webapps/ROOT.war` 가 있으면 기동 시 war 로 다시 배포되므로 웹앱 복구를 하지 않습니다.
- **소유권** : 복구한 파일의 권한(rwx)은 백업 당시대로, 소유자·그룹은 복구 대상 폴더(업로드 폴더, 복구 전 웹앱 폴더)와 같게 맞춥니다.
- 결과는 화면의 `최근 복구` 와 `backup.dir/restore.log` 에 남습니다.

### 6-3. 권한

- 엔지니어 권한(`user.ENGINEER_AUTH_YN = 'Y'`) 사용자만 메뉴가 보이고 조회·다운로드·백업·삭제·복구를 할 수 있습니다. 권한 관리에서 메뉴를 열어 줘도 엔지니어 권한이 없으면 403 입니다.
- 다운로드·백업·삭제·복구 요청은 사용자 ID 와 접속 IP 가 WAS 로그(`catalina.out`)에 `misoBackup` 으로 남습니다.

## 7. 서버 구성별 참고

- **DB 분리** : 포털과 같은 DB 연결을 쓰므로 DB 서버에 설치할 것은 없습니다. 포털 DB 계정 권한
  - 백업 : SELECT, SHOW VIEW, TRIGGER
  - 복구 : DROP, CREATE, ALTER, INSERT, CREATE VIEW, CREATE ROUTINE, TRIGGER
  - 바이너리 로그를 쓰는 DB 에서 SUPER 권한 없이 함수를 복구하면 `log_bin_trust_function_creators=1` 이 필요할 수 있습니다.
- **WEB 분리 (Apache/Nginx)** : `/web/plugins/misoBackup/index.jsp` 요청이 WAS 로 가야 합니다. 큰 백업 파일 다운로드 시 프록시 타임아웃·크기 제한도 확인합니다.
- **WAS 이중화** : WAS 마다 따로 동작합니다.
  - `backup.dir` 이 로컬 디스크면 요청 받은 WAS 에만 저장됩니다. 자동 백업은 한 WAS 에만 `backup.cron` 을 설정합니다.
  - `backup.dir` 이 공유 스토리지면 자동 백업은 한 번만 실행됩니다.
  - 웹앱 복구는 요청 받은 WAS 만 처리합니다.

## 8. 서버 이전

1. 기존 서버에서 백업(DB, 업로드 파일)을 실행합니다.
2. 새 서버에 포털을 설치하고 `./install.sh` 로 이 플러그인을 설치합니다. 경로는 새 서버 기준으로 잡힙니다.
3. 기존 서버 `backup.dir` 의 백업 폴더(`YYYYMMDD_HHMMSS`)를 새 서버 `backup.dir` 아래로 복사합니다. (Tomcat 계정 소유로)
4. 새 서버 메뉴에서 그 백업의 `복구` → 복구 창의 `복구 위치` 확인 → 실행. 웹앱도 복구하면 `system.properties` 등은 새 서버 것이 유지됩니다.
5. DB 를 복구하면 메뉴·권한도 기존 서버 상태가 되므로 다시 로그인합니다.

## 9. 업그레이드

- 새 zip 으로 `./install.sh <Tomcat 경로>` 를 다시 실행합니다. 이미 있는 설정·메뉴·web.xml 은 건너뛰고 플러그인만 바뀝니다. 재기동 없이 다음 요청부터 적용됩니다.
- 포털 war 를 새로 배포하면 `<ROOT>` 가 바뀌어 플러그인이 지워질 수 있습니다. war 배포 후 install.sh 를 다시 실행하거나, 포털 war 에 플러그인을 포함합니다(`src/main/webapp/web/plugins/misoBackup/`).

## 10. 제거

1. `menu_delete.sql` 을 실행합니다.
2. `<ROOT>/web/plugins/misoBackup/` 폴더를 삭제합니다.
3. `<props>` 의 `backup.*` 항목과 `conf/web.xml` 의 `misoBackup` 서블릿을 삭제하고 WAS 를 재기동합니다.
   - 3-6 의 파일을 추가했으면 `/etc/sudoers.d/misobackup`, `/etc/systemd/system/<서비스>.d/misobackup.conf` 도 삭제하고 `systemctl daemon-reload` 합니다.
4. 백업이 더 필요 없으면 `backup.dir` 을 삭제합니다.

## 11. 문제 해결

| 증상 | 확인 |
|---|---|
| install.sh 가 DB 접속 실패로 종료 | `miso.db.url` 의 IP·포트·DB 이름, 계정·비밀번호, DB 서버 방화벽 확인 후 다시 실행 |
| 메뉴가 안 보임 | 로그인 계정의 `user.ENGINEER_AUTH_YN = 'Y'` 확인 후 다시 로그인. 메뉴의 `ENGINEER_YN`, `USE_YN` 이 `Y` 인지 확인 |
| 403 오류 | 엔지니어 권한이 없는 계정 |
| `backup.dir 을 설정하세요`, 백업 버튼 비활성 | `<props>` 의 `backup.dir` 확인 |
| 백업 실패 | `backup.dir` 쓰기 권한(Tomcat 계정)·디스크 여유 공간, `catalina.out` 의 `misoBackup` 메시지 |
| 자동 백업이 안 됨 | `backup.cron` 형식, `conf/web.xml` 서블릿 등록과 재기동 여부 |
| 화면이 안 열리거나 JSP 소스가 보임 | 웹서버가 해당 경로를 WAS 로 넘기는지 확인 (7장 WEB 분리) |
| 웹앱 복구 결과 | `backup.dir/.restore/restore_root.log`, `backup.dir/restore.log` |
| 웹앱 복구 시 `systemd 서비스(...)로 실행 중이라` 오류 | root 로 install.sh 다시 실행 (3-6 설정 추가). 변경 없이 거부된 것 |
| 웹앱 복구 후 WAS 가 꺼져 있음 | `restore_root.log` 가 `WAS 종료` 에서 끊겼으면 3-6 설정 없이 복구 작업이 서비스와 같이 종료된 것. `<Tomcat>/<폴더명>_before_restore_<시각>` 을 원래 웹앱 위치로 되돌리고 WAS 기동 |
